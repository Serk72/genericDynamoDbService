

## Setup Instuctions

### Config
This application is configured using https://github.com/node-config/node-config and can be changed to use `local.json` files for local config or `NODE_ENV` config files.
#### Config File

| Config name                    | JSON Type | Description | Default |
|--------------------------------|-----------|-------------|---------|
| `server.port`                  | Int       | The port the api will run on. | `8000` |
| `dynamodb.tableName`           | String    | The DynamoDb table name to query. | `userInfo` |
| `dynamodb.defaultLimt`         | Int       | The default number of items to return from the `/userInfo` endpoint when listing all users. This value will be used only when no `limit` parameter is sent to the endpoint. | `10` | 
| `dynamodb.maxLimit`            | Int       |
| `dynamodb.removeNulls`         | Boolean   |
| `aws.region`                   | String    |

#### Example Config
```json
{
    "server": {
        "port": 8000
    },
    "dynamodb": {
        "tableName": "userInfo",
        "allowAdditionalInfo": true,
        "defaultLimt": 10,
        "maxLimit": 1000,
        "removeNulls": true
    },
    "aws": {
        "region": "us-east-1"
    }
}
```
# Run Locally
```bash
npm install
npm start
```