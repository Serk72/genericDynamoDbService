# Deployed App Documentation
documentation for an example deployment at `https://w9ov9phvr4.execute-api.us-east-1.amazonaws.com/production/v1`

endpoint documentation available [here](./userDataApi.yml)

Postman tests and documentation available here: https://web.postman.co/workspace/ab57c86c-27d5-4fc4-86d9-129ebbfc8411/api/067d32d3-edcb-4364-ae26-1666a5704a8a/version/615c1822-3244-4281-947e-2986358f68b7
